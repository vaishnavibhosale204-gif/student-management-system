from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Avg, Count, Q
from .models import Student, Mark, Attendance
from .forms import StudentForm, MarkForm, AttendanceForm, BulkAttendanceForm
import json


# ─── DASHBOARD ────────────────────────────────────────────────────────────────
def dashboard(request):
    total_students  = Student.objects.count()
    active_students = Student.objects.filter(status='active').count()
    total_marks     = Mark.objects.count()
    total_att       = Attendance.objects.count()

    # Department distribution
    dept_data = list(
        Student.objects.values('department')
        .annotate(count=Count('id'))
        .order_by('-count')
    )

    # Attendance summary
    att_present = Attendance.objects.filter(status='present').count()
    att_absent  = Attendance.objects.filter(status='absent').count()
    att_late    = Attendance.objects.filter(status='late').count()

    # Recent students
    recent_students = Student.objects.order_by('-created_at')[:5]

    # Top performers (avg marks)
    top_students = []
    for s in Student.objects.filter(mark__isnull=False).distinct():
        avg = s.average_marks()
        if avg:
            top_students.append({'student': s, 'avg': avg})
    top_students = sorted(top_students, key=lambda x: x['avg'], reverse=True)[:5]

    context = {
        'total_students': total_students,
        'active_students': active_students,
        'total_marks': total_marks,
        'total_att': total_att,
        'dept_data': json.dumps(dept_data),
        'att_present': att_present,
        'att_absent': att_absent,
        'att_late': att_late,
        'recent_students': recent_students,
        'top_students': top_students,
    }
    return render(request, 'students/dashboard.html', context)


# ─── STUDENT CRUD ──────────────────────────────────────────────────────────────
def student_list(request):
    q    = request.GET.get('q', '')
    dept = request.GET.get('dept', '')
    year = request.GET.get('year', '')

    students = Student.objects.all()
    if q:    students = students.filter(Q(name__icontains=q) | Q(roll_number__icontains=q))
    if dept: students = students.filter(department__icontains=dept)
    if year: students = students.filter(year=year)

    departments = Student.objects.values_list('department', flat=True).distinct()
    context = {
        'students': students,
        'departments': departments,
        'q': q, 'dept': dept, 'year': year,
    }
    return render(request, 'students/student_list.html', context)


def student_detail(request, pk):
    student    = get_object_or_404(Student, pk=pk)
    marks      = Mark.objects.filter(student=student).order_by('subject')
    attendance = Attendance.objects.filter(student=student).order_by('-date')[:30]
    att_pct    = student.attendance_percentage()
    avg_marks  = student.average_marks()
    return render(request, 'students/student_detail.html', {
        'student': student, 'marks': marks,
        'attendance': attendance, 'att_pct': att_pct, 'avg_marks': avg_marks,
    })


def student_add(request):
    form = StudentForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Student added successfully!')
        return redirect('student_list')
    return render(request, 'students/student_form.html', {'form': form, 'title': 'Add Student'})


def student_edit(request, pk):
    student = get_object_or_404(Student, pk=pk)
    form = StudentForm(request.POST or None, instance=student)
    if form.is_valid():
        form.save()
        messages.success(request, 'Student updated successfully!')
        return redirect('student_detail', pk=pk)
    return render(request, 'students/student_form.html', {'form': form, 'title': 'Edit Student', 'student': student})


def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student.delete()
        messages.success(request, 'Student deleted.')
        return redirect('student_list')
    return render(request, 'students/confirm_delete.html', {'object': student, 'type': 'Student'})


# ─── MARKS ─────────────────────────────────────────────────────────────────────
def mark_list(request):
    marks = Mark.objects.select_related('student').order_by('-exam_date')
    q = request.GET.get('q', '')
    if q:
        marks = marks.filter(Q(student__name__icontains=q) | Q(subject__icontains=q))
    return render(request, 'students/mark_list.html', {'marks': marks, 'q': q})


def mark_add(request):
    form = MarkForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Marks recorded!')
        return redirect('mark_list')
    return render(request, 'students/mark_form.html', {'form': form, 'title': 'Add Marks'})


def mark_edit(request, pk):
    mark = get_object_or_404(Mark, pk=pk)
    form = MarkForm(request.POST or None, instance=mark)
    if form.is_valid():
        form.save()
        messages.success(request, 'Marks updated!')
        return redirect('mark_list')
    return render(request, 'students/mark_form.html', {'form': form, 'title': 'Edit Marks'})


def mark_delete(request, pk):
    mark = get_object_or_404(Mark, pk=pk)
    if request.method == 'POST':
        mark.delete()
        messages.success(request, 'Mark record deleted.')
        return redirect('mark_list')
    return render(request, 'students/confirm_delete.html', {'object': mark, 'type': 'Mark record'})


# ─── ATTENDANCE ────────────────────────────────────────────────────────────────
def attendance_list(request):
    records = Attendance.objects.select_related('student').order_by('-date')[:100]
    return render(request, 'students/attendance_list.html', {'records': records})


def attendance_add(request):
    form = AttendanceForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Attendance recorded!')
        return redirect('attendance_list')
    return render(request, 'students/attendance_form.html', {'form': form, 'title': 'Mark Attendance'})


def bulk_attendance(request):
    students = Student.objects.filter(status='active')
    form = BulkAttendanceForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        date    = form.cleaned_data['date']
        subject = form.cleaned_data['subject']
        saved = 0
        for student in students:
            status = request.POST.get(f'status_{student.id}', 'absent')
            obj, created = Attendance.objects.get_or_create(
                student=student, date=date, subject=subject,
                defaults={'status': status}
            )
            if not created:
                obj.status = status
                obj.save()
            saved += 1
        messages.success(request, f'Attendance saved for {saved} students!')
        return redirect('attendance_list')

    return render(request, 'students/bulk_attendance.html', {'form': form, 'students': students})
