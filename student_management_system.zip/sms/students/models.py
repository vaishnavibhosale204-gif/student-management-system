from django.db import models

class Student(models.Model):
    GENDER_CHOICES = [('M', 'Male'), ('F', 'Female'), ('O', 'Other')]
    STATUS_CHOICES = [('active', 'Active'), ('inactive', 'Inactive')]

    roll_number = models.CharField(max_length=20, unique=True)
    name        = models.CharField(max_length=100)
    email       = models.EmailField(unique=True)
    phone       = models.CharField(max_length=15, blank=True)
    gender      = models.CharField(max_length=1, choices=GENDER_CHOICES)
    dob         = models.DateField(null=True, blank=True)
    department  = models.CharField(max_length=100)
    year        = models.IntegerField(choices=[(1,'First'),(2,'Second'),(3,'Third'),(4,'Fourth')])
    address     = models.TextField(blank=True)
    status      = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    created_at  = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.roll_number} - {self.name}"

    def attendance_percentage(self):
        records = self.attendance_set.all()
        if not records.exists():
            return None
        present = records.filter(status='present').count()
        return round((present / records.count()) * 100, 1)

    def average_marks(self):
        marks = self.mark_set.all()
        if not marks.exists():
            return None
        total = sum(m.marks_obtained for m in marks)
        return round(total / marks.count(), 1)


SUBJECT_CHOICES = [
    ('Mathematics',   'Mathematics'),
    ('Science',       'Science'),
    ('English',       'English'),
    ('History',       'History'),
    ('Computer',      'Computer Science'),
    ('Physics',       'Physics'),
    ('Chemistry',     'Chemistry'),
    ('Other',         'Other'),
]

class Mark(models.Model):
    GRADE_CHOICES = [
        ('O','Outstanding (O)'), ('A+','Excellent (A+)'), ('A','Very Good (A)'),
        ('B+','Good (B+)'), ('B','Above Average (B)'), ('C','Average (C)'),
        ('D','Pass (D)'), ('F','Fail (F)'),
    ]

    student       = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject       = models.CharField(max_length=100, choices=SUBJECT_CHOICES)
    exam_type     = models.CharField(max_length=50, choices=[
                        ('Unit Test 1','Unit Test 1'), ('Unit Test 2','Unit Test 2'),
                        ('Mid-Term','Mid-Term'), ('Final','Final Exam'),
                        ('Practical','Practical'), ('Assignment','Assignment'),
                    ])
    marks_obtained = models.FloatField()
    max_marks      = models.FloatField(default=100)
    grade          = models.CharField(max_length=3, choices=GRADE_CHOICES, blank=True)
    exam_date      = models.DateField()
    remarks        = models.CharField(max_length=200, blank=True)

    class Meta:
        unique_together = ('student', 'subject', 'exam_type')

    def __str__(self):
        return f"{self.student.name} - {self.subject} - {self.exam_type}"

    def percentage(self):
        return round((self.marks_obtained / self.max_marks) * 100, 1)

    def save(self, *args, **kwargs):
        pct = self.percentage()
        if pct >= 90:   self.grade = 'O'
        elif pct >= 80: self.grade = 'A+'
        elif pct >= 70: self.grade = 'A'
        elif pct >= 60: self.grade = 'B+'
        elif pct >= 50: self.grade = 'B'
        elif pct >= 40: self.grade = 'C'
        elif pct >= 33: self.grade = 'D'
        else:           self.grade = 'F'
        super().save(*args, **kwargs)


class Attendance(models.Model):
    STATUS_CHOICES = [('present','Present'), ('absent','Absent'), ('late','Late')]

    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date    = models.DateField()
    subject = models.CharField(max_length=100, choices=SUBJECT_CHOICES)
    status  = models.CharField(max_length=10, choices=STATUS_CHOICES)
    remarks = models.CharField(max_length=200, blank=True)

    class Meta:
        unique_together = ('student', 'date', 'subject')

    def __str__(self):
        return f"{self.student.name} - {self.date} - {self.subject} - {self.status}"
