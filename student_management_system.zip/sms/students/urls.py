from django.urls import path
from . import views

urlpatterns = [
    path('',                        views.dashboard,        name='dashboard'),
    # Students
    path('students/',               views.student_list,     name='student_list'),
    path('students/add/',           views.student_add,      name='student_add'),
    path('students/<int:pk>/',      views.student_detail,   name='student_detail'),
    path('students/<int:pk>/edit/', views.student_edit,     name='student_edit'),
    path('students/<int:pk>/delete/', views.student_delete, name='student_delete'),
    # Marks
    path('marks/',                  views.mark_list,        name='mark_list'),
    path('marks/add/',              views.mark_add,         name='mark_add'),
    path('marks/<int:pk>/edit/',    views.mark_edit,        name='mark_edit'),
    path('marks/<int:pk>/delete/',  views.mark_delete,      name='mark_delete'),
    # Attendance
    path('attendance/',             views.attendance_list,  name='attendance_list'),
    path('attendance/add/',         views.attendance_add,   name='attendance_add'),
    path('attendance/bulk/',        views.bulk_attendance,  name='bulk_attendance'),
]
