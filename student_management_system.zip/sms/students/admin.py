from django.contrib import admin
from .models import Student, Mark, Attendance

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display  = ['roll_number', 'name', 'department', 'year', 'status']
    list_filter   = ['department', 'year', 'status']
    search_fields = ['name', 'roll_number', 'email']

@admin.register(Mark)
class MarkAdmin(admin.ModelAdmin):
    list_display  = ['student', 'subject', 'exam_type', 'marks_obtained', 'max_marks', 'grade']
    list_filter   = ['subject', 'exam_type', 'grade']
    search_fields = ['student__name']

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display  = ['student', 'date', 'subject', 'status']
    list_filter   = ['status', 'subject', 'date']
    search_fields = ['student__name']
