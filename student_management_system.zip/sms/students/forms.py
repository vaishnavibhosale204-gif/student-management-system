from django import forms
from .models import Student, Mark, Attendance

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['roll_number','name','email','phone','gender','dob',
                  'department','year','address','status']
        widgets = {
            'dob':     forms.DateInput(attrs={'type': 'date'}),
            'address': forms.Textarea(attrs={'rows': 3}),
        }

class MarkForm(forms.ModelForm):
    class Meta:
        model = Mark
        fields = ['student','subject','exam_type','marks_obtained','max_marks','exam_date','remarks']
        widgets = {
            'exam_date': forms.DateInput(attrs={'type': 'date'}),
        }

class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['student','date','subject','status','remarks']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }

class BulkAttendanceForm(forms.Form):
    date    = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    subject = forms.ChoiceField(choices=[('','-- Select Subject --')] + list(Mark._meta.get_field('subject').choices))
