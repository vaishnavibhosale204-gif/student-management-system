# 🎓 EduTrack — Student Management System
A full-featured Django web app with CRUD, Marks, Attendance, and Dashboard with Charts.

---

## ⚡ Quick Setup (5 minutes)

### 1. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows
```

### 2. Install Django
```bash
pip install -r requirements.txt
```

### 3. Run migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 4. Create admin user
```bash
python manage.py createsuperuser
```

### 5. Start the server
```bash
python manage.py runserver
```

### 6. Open browser
- App:   http://127.0.0.1:8000/
- Admin: http://127.0.0.1:8000/admin/

---

## 📁 Project Structure
```
sms/
├── manage.py
├── requirements.txt
├── db.sqlite3              ← auto-created on migrate
├── sms_project/
│   ├── settings.py
│   └── urls.py
└── students/
    ├── models.py           ← Student, Mark, Attendance
    ├── views.py            ← All logic
    ├── forms.py            ← Django forms
    ├── urls.py             ← URL routes
    ├── admin.py            ← Admin panel
    └── templates/students/
        ├── base.html       ← Sidebar layout
        ├── dashboard.html  ← Charts + stats
        ├── student_list.html
        ├── student_detail.html
        ├── student_form.html
        ├── mark_list.html
        ├── mark_form.html
        ├── attendance_list.html
        ├── attendance_form.html
        ├── bulk_attendance.html
        └── confirm_delete.html
```

---

## ✅ Features
| Feature | Details |
|---|---|
| Student CRUD | Add, edit, delete, view students |
| Marks | Record subject-wise marks, auto-calculates grade |
| Attendance | Single or bulk (mark entire class at once) |
| Dashboard | Stats cards + Attendance donut chart + Dept bar chart |
| Search | Filter students by name, roll no, dept, year |
| Auto Grade | O/A+/A/B+/B/C/D/F based on percentage |
| Admin Panel | Full Django admin at /admin/ |

---

## 🗃️ Models
- **Student** — roll_number, name, email, phone, gender, dob, department, year, address, status
- **Mark** — student (FK), subject, exam_type, marks_obtained, max_marks, grade (auto), exam_date
- **Attendance** — student (FK), date, subject, status (present/absent/late)

---

## 💡 Add Sample Data
Use Django admin at `/admin/` or the app's Add Student form to add test data.
